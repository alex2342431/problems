#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QListWidget>
#include "listofequip.h"
#include "infoofequip.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowFlags(Qt::Window | Qt::MSWindowsFixedSizeDialogHint);

    ui->listWidget->addItem(new QListWidgetItem(QIcon(":/img/img/home_normal.png"), "Аналитика"));
    ui->listWidget->addItem("типо второй пункт");
    widgets.push_back(new ListOfEquip());
    widgets.push_back(new InfoOfEquip()); //не относится ко второму пункту

    ui->listWidget->setIconSize(QSize(35, 35));

    for(unsigned int i = 0; i < widgets.size(); ++i) {
        ui->stackedWidget->insertWidget(i, widgets[i]);
    }

    ui->listWidget->setCurrentRow(0);


    QSize iconSize = QSize(ui->messageButton->size().height() - 35, ui->messageButton->size().width() - 35);
    ui->messageButton->setIcon(QIcon(QPixmap(":/img/img/message.png")));
    ui->messageButton->setIconSize(iconSize);
    ui->notificationButton->setIcon(QIcon(QPixmap(":/img/img/notification.png")));
    ui->notificationButton->setIconSize(iconSize);
    ui->settingsButton->setIcon(QIcon(QPixmap(":/img/img/settings.png")));
    ui->settingsButton->setIconSize(iconSize);

    ui->logoImage->setPixmap(QPixmap(":/img/img/CSHU_logo.png").scaled(ui->logoImage->size()));

    connect(widgets[0], SIGNAL(OpenInfo()), this, SLOT(OpenInfoFromList()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_listWidget_currentRowChanged(int currentRow)
{
    ui->stackedWidget->setCurrentIndex(currentRow);
}


void MainWindow::on_listWidget_currentItemChanged(QListWidgetItem *current, QListWidgetItem *previous)
{
    //менять цвета иконок
}

void MainWindow::OpenInfoFromList()
{
    ui->stackedWidget->setCurrentIndex(1);
    //can send signal to info widget with information of what exact object to open info about
}

