#ifndef LISTOFEQUIP_H
#define LISTOFEQUIP_H

#include <QWidget>

namespace Ui {
class ListOfEquip;
}

class ListOfEquip : public QWidget
{
    Q_OBJECT

public:
    explicit ListOfEquip(QWidget *parent = nullptr);
    ~ListOfEquip();
private slots:

    void on_tableWidget_cellDoubleClicked(int row, int column);

private:
    Ui::ListOfEquip *ui;

signals:

    void OpenInfo();
};

#endif // LISTOFEQUIP_H
