#include "infoofequip.h"
#include "ui_infoofequip.h"

InfoOfEquip::InfoOfEquip(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::InfoOfEquip)
{
    ui->setupUi(this);

    QPixmap image = QPixmap(":/img/img/MFU.png");
    ui->image->setPixmap(image.scaled(ui->groupBox->size().width()/4, (image.size().height() * ui->groupBox->size().width()/4)/image.size().width()));
}

InfoOfEquip::~InfoOfEquip()
{
    delete ui;
}
