#include "listofequip.h"
#include "ui_listofequip.h"

ListOfEquip::ListOfEquip(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::ListOfEquip)
{
    ui->setupUi(this);

    //не работает
    //ui->lineEdit->setWindowIcon(QIcon(QPixmap(":/img/img/home_normal.png")));
    //ui->lineEdit->setIconSize(ui->lineEdit->size());

    ui->search_icon->setPixmap(QPixmap(":/img/img/search.png").scaled(QSize(ui->lineEdit->size().height(), ui->lineEdit->size().height())));

    ui->arrow_stat_all->setPixmap(QPixmap(":/img/img/arrow_red.png").scaled(ui->arrow_stat_all->size().height(), ui->arrow_stat_all->size().height()));
    ui->arrow_stat_printer->setPixmap(QPixmap(":/img/img/arrow_green.png").scaled(ui->arrow_stat_printer->size().height(), ui->arrow_stat_printer->size().height()));
    ui->arrow_stat_mfu->setPixmap(QPixmap(":/img/img/arrow_red.png").scaled(ui->arrow_stat_mfu->size().height(), ui->arrow_stat_mfu->size().height()));
    ui->arrow_stat_rent->setPixmap(QPixmap(":/img/img/arrow_red.png").scaled(ui->arrow_stat_rent->size().height(), ui->arrow_stat_rent->size().height()));

    ui->stat_icon_all->setPixmap(QPixmap(":/img/img/stat_icon_green.png").scaled(ui->stat_group_all->size().height()/3, ui->stat_group_all->size().height()/3));
    ui->stat_icon_printer->setPixmap(QPixmap(":/img/img/stat_icon_green.png").scaled(ui->stat_group_printer->size().height()/3, ui->stat_group_printer->size().height()/3));
    ui->stat_icon_mfu->setPixmap(QPixmap(":/img/img/stat_icon_green.png").scaled(ui->stat_group_mfu->size().height()/3, ui->stat_group_mfu->size().height()/3));
    ui->stat_icon_rent->setPixmap(QPixmap(":/img/img/stat_icon_red.png").scaled(ui->stat_group_rent->size().height()/3, ui->stat_group_rent->size().height()/3));

    //table
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeMode::Stretch);

    //test row
    ui->tableWidget->setRowCount(1);

    ui->tableWidget->setItem(0, 0, new QTableWidgetItem(QString("410134200000112")));
    ui->tableWidget->setItem(0, 1, new QTableWidgetItem(QString("Keycera 2540 DN")));
    ui->tableWidget->setItem(0, 2, new QTableWidgetItem(QString("МФУ")));
    ui->tableWidget->setItem(0, 3, new QTableWidgetItem(QString("пр-т Луначарского 5 - 112")));
    ui->tableWidget->setItem(0, 4, new QTableWidgetItem(QString("0")));
    ui->tableWidget->setItem(0, 5, new QTableWidgetItem(QString("0")));
}

ListOfEquip::~ListOfEquip()
{
    delete ui;
}


void ListOfEquip::on_tableWidget_cellDoubleClicked(int row, int column)
{
    emit OpenInfo();
}



