#ifndef INFOOFEQUIP_H
#define INFOOFEQUIP_H

#include <QWidget>

namespace Ui {
class InfoOfEquip;
}

class InfoOfEquip : public QWidget
{
    Q_OBJECT

public:
    explicit InfoOfEquip(QWidget *parent = nullptr);
    ~InfoOfEquip();

private:
    Ui::InfoOfEquip *ui;
};

#endif // INFOOFEQUIP_H
